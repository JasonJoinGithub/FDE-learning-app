#!/bin/bash
# 打开 FDE 学习台（macOS / Linux）
cd "$(dirname "$0")" || exit 1
if command -v open >/dev/null 2>&1; then
  open "FDE学习App.html"
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "FDE学习App.html"
else
  echo "请手动用浏览器打开：$(pwd)/FDE学习App.html"
fi
