# -*- coding: utf-8 -*-
"""
生成 FDE 学习 App：单文件 HTML，离线可用，进度存 localStorage。

用法：python3 build_app.py
输出：FDE学习App.html
"""

import json
import pathlib

OUT = pathlib.Path(__file__).parent / "FDE学习App.html"

# ============================================================
# 课程内容
# ============================================================

WEEKS = [
    {
        "n": 1,
        "title": "电脑和程序是什么",
        "goal": "搞懂「程序就是一堆按顺序执行的指令」，并且能写出、运行你的第一个文件。",
        "deliverable": "一个能读文件、数行数、打印结果的小程序（20–30 行）",
        "days": [
            {
                "d": 1,
                "title": "扫盲：电脑到底在干什么",
                "learn": "电脑只会做三件事：把数据搬来搬去、做简单计算、根据条件决定下一步。所谓「程序」，就是人写给它的一串指令。你写的代码，最后会变成这些指令。",
                "concepts": [
                    ("程序", "一串按顺序执行的指令。电脑不会猜你的意思，它只照着做。"),
                    ("源代码", "你写的 .py 文件。人看得懂，电脑不能直接跑。"),
                    ("解释器", "Python 解释器负责把你的 .py 一行一行翻译成电脑能执行的动作。"),
                    ("终端", "你给电脑下命令的窗口。不是黑魔法，就是一个输入框。"),
                ],
                "tasks": [
                    "打开终端（启动台搜「终端」）",
                    "输入 pwd 回车，看它输出什么（这是你当前所在目录）",
                    "输入 ls 回车，看你目录里有什么",
                    "输入 python3 -V 回车，看版本号",
                    "输入 python3 -c \"print(1+1)\" 回车，看它算出来",
                ],
                "code": "",
                "check": [
                    "能说出「程序」是什么（一句话）",
                    "知道 pwd / ls / python3 -V 各自干什么",
                    "看到 python3 -c \"print(1+1)\" 输出 2",
                ],
            },
            {
                "d": 2,
                "title": "装好你的工作台",
                "learn": "今天不学编程，只把工具装好。装完之后你能：新建文件、写代码、运行、看懂报错。",
                "concepts": [
                    ("VS Code", "代码编辑器。比记事本强的地方：高亮、补全、能看目录。"),
                    ("文件扩展名", ".py 结尾的文件才是 Python 程序。写成 .txt 就跑不了。"),
                    ("当前目录", "终端里你「站」的位置。运行 python3 x.py 时，它是在当前目录找 x.py。"),
                ],
                "tasks": [
                    "装 VS Code：https://code.visualstudio.com/ （下载后拖进「应用程序」）",
                    "VS Code 里按 Cmd+Shift+P，输入 shell command，选 Install 'code' command in PATH",
                    "终端执行：mkdir -p ~/fde-code/week1 && cd ~/fde-code/week1",
                    "终端执行：code . （应该打开 VS Code）",
                    "新建 hello.py，写 print(\"hello\") ，保存",
                    "终端执行：python3 hello.py",
                ],
                "code": 'print("hello")\nprint("我今天开始学 FDE")',
                "check": [
                    "VS Code 能打开 ~/fde-code/week1",
                    "python3 hello.py 能输出两行字",
                    "知道 .py 文件必须放在当前目录才能被找到",
                ],
            },
            {
                "d": 3,
                "title": "学会看报错（今天最重要）",
                "learn": "报错不是失败，是 Python 在告诉你哪里不对。学会读报错，比学会写代码更早要用。",
                "concepts": [
                    ("SyntaxError", "语法错。最常见：括号、引号、冒号没配对。"),
                    ("Traceback", "调用栈。告诉你错误发生在哪个文件、哪一行、哪一层。"),
                    ("行号", "报错里 File \"...\", line N 的 N。永远先看这个。"),
                ],
                "tasks": [
                    "把 hello.py 改成 print(\"hello\" （故意少一个右括号），保存",
                    "运行 python3 hello.py，观察报错",
                    "找出报错里的三样东西：文件、行号、错误类型",
                    "修好它，再运行一次",
                    "再故意制造一个错：把 print 拼成 pritn，看报什么错",
                ],
                "code": 'print("hello"  # ← 故意少一个右括号，运行看报错',
                "check": [
                    "能指出报错里的文件、行号、错误类型",
                    "能修好「括号没闭合」",
                    "知道 NameError 和 SyntaxError 的区别",
                ],
            },
            {
                "d": 4,
                "title": "变量与类型：数据有形状",
                "learn": "程序处理的是数据，数据有类型。字符串是文字，整数是数字，小数是带小数点的数字。类型不对，运算就会出错。",
                "concepts": [
                    ("变量", "给一个值起个名字。a = 1 意思是「把 1 叫做 a」。"),
                    ("字符串 str", "文字。必须用引号包起来。\"你好\" 或 '你好' 都行。"),
                    ("整数 int / 小数 float", "数字。1 是 int，1.5 是 float。"),
                    ("类型转换", "str(123) 把数字变文字，int(\"123\") 把文字变数字。不转就会报 TypeError。"),
                ],
                "tasks": [
                    "新建 types.py",
                    "写：name = \"你的名字\" / age = 30 / height = 1.75",
                    "分别 print 它们，再 print(type(name)) 看类型",
                    "试着 print(\"我今年\" + age)，看报错（字符串 + 数字）",
                    "改成 print(\"我今年\" + str(age))，看能不能跑",
                ],
                "code": 'name = "你的名字"\nage = 30\nheight = 1.75\n\nprint(name)\nprint(type(name))\nprint(type(age))\nprint("我今年 " + str(age) + " 岁")',
                "check": [
                    "能说出 str / int / float 的区别",
                    "知道为什么字符串不能直接加数字",
                    "会用 str() 和 int() 转换",
                ],
            },
            {
                "d": 5,
                "title": "条件：让程序做判断",
                "learn": "程序会「看情况」。如果……就……否则……。这是所有业务规则的起点。",
                "concepts": [
                    ("if / elif / else", "如果 / 否则如果 / 否则。按顺序判断，命中一个就跳出。"),
                    ("比较运算符", "> < >= <= == != 。注意「等于」是两个等号。"),
                    ("缩进", "Python 用缩进表示「属于这个 if」。缩进错了逻辑就错。"),
                ],
                "tasks": [
                    "新建 judge.py",
                    "写一个程序：给一个分数，输出「及格」或「不及格」",
                    "加一档：90 分以上输出「优秀」",
                    "故意把缩进改乱，看报错 IndentationError",
                    "再写一个：判断一个字幕时长是否小于 0.8 秒",
                ],
                "code": 'score = 85\n\nif score >= 90:\n    print("优秀")\nelif score >= 60:\n    print("及格")\nelse:\n    print("不及格")',
                "check": [
                    "能写出 if / elif / else 三段判断",
                    "知道 == 和 = 的区别",
                    "知道缩进错了会报 IndentationError",
                ],
            },
            {
                "d": 6,
                "title": "循环：对一堆东西做同一件事",
                "learn": "真实任务永远是「一堆」，不是一个。循环就是「对每一个都做一遍」。",
                "concepts": [
                    ("for 循环", "for x in 一堆东西: 把每个元素轮流给 x，然后执行下面的代码。"),
                    ("range", "range(5) 生成 0,1,2,3,4。注意从 0 开始。"),
                    ("累加", "count = count + 1 或 count += 1。先算右边，再赋给左边。"),
                ],
                "tasks": [
                    "新建 loop.py",
                    "用 for 打印 1 到 5",
                    "用 for 累加 1 到 100，输出结果（应该是 5050）",
                    "给一个列表 [3, 1, 4, 1, 5]，用循环找出最大值",
                ],
                "code": 'total = 0\nfor i in range(1, 101):\n    total += i\nprint("1 到 100 的和：", total)\n\nnums = [3, 1, 4, 1, 5]\nbiggest = nums[0]\nfor n in nums:\n    if n > biggest:\n        biggest = n\nprint("最大值：", biggest)',
                "check": [
                    "能写出 for 循环累加",
                    "能手动找出列表最大值",
                    "知道 range(1, 101) 是 1 到 100（不含 101）",
                ],
            },
            {
                "d": 7,
                "title": "周项目：读文件、统计、输出",
                "learn": "把这一周学的全用上：读一个文本文件，数行数、空行数、最长行。这就是「输入 → 处理 → 输出」的完整形状。",
                "concepts": [
                    ("open()", "打开文件。必须写 encoding=\"utf-8\"，否则中文会乱码。"),
                    ("readlines()", "把文件按行读成一个列表，每行是一个元素。"),
                    ("strip()", "去掉字符串首尾的空白和换行符。判断空行必须用 line.strip() == \"\"。"),
                    ("with", "with open(...) as f: 会自动关闭文件，比手动 close() 安全。"),
                ],
                "tasks": [
                    "在 week1 目录造一个 sample.txt（5 行，其中一行是空行）",
                    "写 count.py：读文件，输出总行数",
                    "升级：输出空行数（提示：line.strip() == \"\"）",
                    "再升级：输出最长行的字数",
                    "关掉 AI，从空白重写一遍（限时 60 分钟）",
                ],
                "code": 'def read_file(path):\n    with open(path, "r", encoding="utf-8") as f:\n        return f.readlines()\n\n\ndef analyze(lines):\n    total = len(lines)\n    empty = 0\n    max_len = 0\n    for line in lines:\n        if line.strip() == "":\n            empty += 1\n        if len(line.strip()) > max_len:\n            max_len = len(line.strip())\n    return {"total": total, "empty": empty, "max_len": max_len}\n\n\nif __name__ == "__main__":\n    lines = read_file("sample.txt")\n    result = analyze(lines)\n    print("总行数：", result["total"])\n    print("空行数：", result["empty"])\n    print("最长行字数：", result["max_len"])',
                "check": [
                    "count.py 能输出总行数、空行数、最长行字数",
                    "能说清 strip() 为什么不能省",
                    "能关掉 AI 在 60 分钟内写出能跑的版本",
                ],
            },
        ],
    },
    {
        "n": 2,
        "title": "数据怎么流",
        "goal": "搞懂列表、字典、函数、参数，能写 40–60 行的小工具，并且第一次读别人的代码。",
        "deliverable": "一个支持命令行参数、能批量处理文件夹、有测试的小工具",
        "days": [
            {
                "d": 8,
                "title": "列表：一排东西",
                "learn": "列表是最常用的容器。字幕条目、文件列表、价格表，全都是列表。",
                "concepts": [
                    ("列表 list", "items = [1, 2, 3]。有顺序，可以改。"),
                    ("索引", "items[0] 是第一个（从 0 开始），items[-1] 是最后一个。"),
                    ("append / len", "items.append(4) 加一个，len(items) 看有几个。"),
                    ("切片", "items[0:2] 取前两个。左闭右开。"),
                ],
                "tasks": [
                    "新建 list_demo.py",
                    "造一个列表，打印第一个、最后一个、长度",
                    "用 append 加一个，再用 len 看变化",
                    "用 for 循环打印每个元素",
                    "用 sorted() 排序后打印",
                ],
                "code": 'items = ["第一条", "第二条", "第三条"]\n\nprint(items[0])\nprint(items[-1])\nprint(len(items))\n\nitems.append("第四条")\nprint(len(items))\n\nfor it in items:\n    print(it)',
                "check": [
                    "知道索引从 0 开始",
                    "知道 [-1] 是最后一个",
                    "会用 append 和 len",
                ],
            },
            {
                "d": 9,
                "title": "字典：给每个东西记一个值",
                "learn": "列表是「一排」，字典是「一对一」。统计次数、存配置、表示一条记录，全靠字典。",
                "concepts": [
                    ("字典 dict", "d = {\"name\": \"张三\", \"age\": 30}。键值对。"),
                    ("取值", "d[\"name\"] 取不到会报 KeyError；d.get(\"name\", 默认值) 不会报错。"),
                    ("遍历", "for k, v in d.items(): 同时拿到键和值。"),
                    ("为什么用 get", "真实数据经常缺字段。用 [] 会崩，用 get 能兜住。"),
                ],
                "tasks": [
                    "新建 dict_demo.py",
                    "造一个字典，存一个项目的名字、星数、许可证",
                    "print 每个字段",
                    "故意取一个不存在的键，看 KeyError",
                    "改用 .get() 再试一次",
                ],
                "code": 'repo = {"name": "subtitle-qc", "stars": 120, "license": "MIT"}\n\nprint(repo["name"])\nprint(repo.get("stars"))\nprint(repo.get("owner", "未知"))   # 不存在也不报错\n\nfor k, v in repo.items():\n    print(k, "=", v)',
                "check": [
                    "能创建字典并取值",
                    "能说清 [] 和 get() 的区别",
                    "知道 KeyError 是什么",
                ],
            },
            {
                "d": 10,
                "title": "函数：给一段代码起名字",
                "learn": "函数把「做一件事」打包起来。好处：可以重复用、可以单独测、改的时候只改一处。",
                "concepts": [
                    ("def", "def 函数名(参数): 定义函数。"),
                    ("参数", "函数需要的输入。可以多个，也可以有默认值。"),
                    ("return", "把结果交出去。不写 return，函数返回 None。"),
                    ("print vs return", "print 是给人看，return 是给程序用。混了就会出 bug。"),
                ],
                "tasks": [
                    "新建 func_demo.py",
                    "写 def add(a, b): return a + b",
                    "调用它，print(add(2, 3))",
                    "写一个函数：判断一个字符串是不是空（返回 True/False）",
                    "故意写一个只 print 不 return 的函数，看调用方拿到什么",
                ],
                "code": 'def add(a, b):\n    return a + b\n\n\ndef is_blank(text):\n    return text.strip() == ""\n\n\nprint(add(2, 3))\nprint(is_blank("   "))\nprint(is_blank("你好"))\n\n\ndef bad(a, b):\n    print(a + b)   # 只打印，没有 return\n\n\nresult = bad(1, 2)\nprint("返回值是：", result)   # None',
                "check": [
                    "能定义并调用函数",
                    "能说清 print 和 return 的区别",
                    "知道不写 return 会返回 None",
                ],
            },
            {
                "d": 11,
                "title": "命令行参数：让程序听人话",
                "learn": "程序不该把文件名写死在代码里。真实工具都是「运行时告诉它处理哪个文件」。",
                "concepts": [
                    ("sys.argv", "一个列表，装着你敲命令时给的所有参数。"),
                    ("argv[0]", "固定是脚本自己的名字。"),
                    ("argv[1]", "第一个参数（你要处理的文件）。"),
                    ("参数检查", "len(sys.argv) < 2 说明用户没给参数，要给提示而不是崩。"),
                ],
                "tasks": [
                    "新建 args.py，打印 sys.argv 看看它长什么样",
                    "加检查：没给参数时打印用法",
                    "给它一个文件路径参数，读这个文件",
                    "传一个不存在的文件，看 FileNotFoundError",
                ],
                "code": 'import sys\n\n\ndef main():\n    if len(sys.argv) < 2:\n        print("用法：python3 args.py <文件路径>")\n        return\n\n    path = sys.argv[1]\n    print("要读的文件：", path)\n    with open(path, "r", encoding="utf-8") as f:\n        lines = f.readlines()\n    print("行数：", len(lines))\n\n\nif __name__ == "__main__":\n    main()',
                "check": [
                    "知道 sys.argv 是什么",
                    "知道 argv[0] 和 argv[1] 的区别",
                    "不带参数时程序有提示、不崩",
                ],
            },
            {
                "d": 12,
                "title": "JSON：最常见的结构化数据",
                "learn": "真实系统的数据几乎都是 JSON。它就是「带键的数据」，Python 里对应 dict 和 list。",
                "concepts": [
                    ("JSON", "{\"name\": \"x\", \"stars\": 10}。和 Python 字典长得几乎一样。"),
                    ("json.load", "从文件读 JSON，变成 Python 对象。"),
                    ("json.dumps", "把 Python 对象变回 JSON 字符串。ensure_ascii=False 让中文正常显示。"),
                    ("null", "JSON 的 null 对应 Python 的 None。"),
                ],
                "tasks": [
                    "新建 repos.json，写 3 个项目的数组",
                    "写 read_json.py 读它并打印每个项目名",
                    "打印一共有几个项目",
                    "过滤掉没有 license 的项目，只打印有许可证的",
                ],
                "code": 'import json\n\n\ndef load(path):\n    with open(path, "r", encoding="utf-8") as f:\n        return json.load(f)\n\n\nrepos = load("repos.json")\nprint("一共", len(repos), "个项目")\n\nfor r in repos:\n    if not r.get("license"):\n        continue\n    print(r["name"], "|", r["stars"], "|", r["license"])',
                "check": [
                    "能读 JSON 文件",
                    "知道 JSON 的 null 对应 None",
                    "能过滤字段缺失的数据",
                ],
            },
            {
                "d": 13,
                "title": "CSV：脏数据的日常",
                "learn": "CSV 看着简单，坑很多：逗号、引号、空字段、全是字符串。真实交付里 80% 的时间在处理这些。",
                "concepts": [
                    ("csv.DictReader", "自动用第一行当键名，每行变成字典。"),
                    ("所有值都是字符串", "CSV 读出来 \"120\" 是文字，不是数字。要 int() 转换。"),
                    ("newline=\"\"", "打开 CSV 必须加这个参数，否则换行会出问题。"),
                    ("脏数据", "缺字段、格式错、重复行。清洗是必经步骤。"),
                ],
                "tasks": [
                    "新建 projects.csv，写 4 行，故意留一个空字段",
                    "写 read_csv.py，用 DictReader 读出来",
                    "打印原始行数",
                    "跳过 owner 为空的行，打印跳过了几条",
                    "把 stars 转成数字并排序",
                ],
                "code": 'import csv\n\n\nwith open("projects.csv", "r", encoding="utf-8", newline="") as f:\n    reader = csv.DictReader(f)\n    rows = list(reader)\n\nprint("原始行数：", len(rows))\n\nclean = []\nfor r in rows:\n    if not r.get("owner"):\n        continue\n    r["stars"] = int(r["stars"])\n    clean.append(r)\n\nclean.sort(key=lambda r: r["stars"], reverse=True)\nfor r in clean:\n    print(r["name"], r["stars"])',
                "check": [
                    "能用 DictReader 读 CSV",
                    "知道为什么所有值都是字符串",
                    "能过滤并排序",
                ],
            },
            {
                "d": 14,
                "title": "周项目：批量处理 + 第一次读别人的代码",
                "learn": "把这一周学的串起来：传一个文件夹，处理里面所有 txt，出汇总。然后第一次去读你 SkillRadar 里的一个函数。",
                "concepts": [
                    ("os.listdir", "列出文件夹里的文件名（不含路径）。"),
                    ("os.path.join", "拼完整路径。folder + name 手拼会漏斜杠。"),
                    ("continue", "跳过这一个，继续下一个。用来过滤文件。"),
                    ("sorted", "让处理顺序稳定，测试才可靠。"),
                ],
                "tasks": [
                    "建 files/ 文件夹，造 3 个 txt",
                    "写 batch.py：传文件夹，处理所有 .txt，输出每个文件的行数",
                    "最后输出文件总数和总行数",
                    "传一个不存在的文件夹，看有没有友好提示",
                    "读 SkillRadar 的 slugify 函数，回答：吃进什么、吐出什么、会不会返回空",
                ],
                "code": 'import os\nimport sys\n\n\ndef analyze_one(path):\n    with open(path, "r", encoding="utf-8") as f:\n        lines = f.readlines()\n    total = len(lines)\n    empty = sum(1 for line in lines if line.strip() == "")\n    return {"path": path, "total": total, "empty": empty}\n\n\ndef main():\n    if len(sys.argv) < 2:\n        print("用法：python3 batch.py <文件夹>")\n        return\n    folder = sys.argv[1]\n    if not os.path.isdir(folder):\n        print("不是文件夹：", folder)\n        return\n\n    results = []\n    for name in sorted(os.listdir(folder)):\n        if not name.endswith(".txt"):\n            continue\n        results.append(analyze_one(os.path.join(folder, name)))\n\n    for r in results:\n        print(r["path"], "行数", r["total"], "空行", r["empty"])\n    print("---")\n    print("文件总数：", len(results))\n    print("总行数：", sum(r["total"] for r in results))\n\n\nif __name__ == "__main__":\n    main()',
                "check": [
                    "batch.py 能处理文件夹并汇总",
                    "不存在的文件夹有提示",
                    "能回答 SkillRadar 的 slugify 的 5 个问题（哪怕答不全）",
                ],
            },
        ],
    },
    {
        "n": 3,
        "title": "让代码经得起折腾",
        "goal": "学会错误处理、测试、调试、重构。从「能跑」变成「改得动、坏不了」。",
        "deliverable": "有 5 个以上测试、能处理异常输入的工具",
        "days": [
            {
                "d": 15,
                "title": "错误处理：出错要接住",
                "learn": "真实世界的数据是脏的。程序不能一遇到坏文件就崩，要给人话提示。",
                "concepts": [
                    ("try / except", "把可能出错的放 try，出错跳到 except，程序不崩。"),
                    ("具体异常", "except FileNotFoundError 比 except Exception 好，知道在防什么。"),
                    ("返回 None", "表示「没有结果」。调用方必须检查 if x is None。"),
                    ("预防 vs 兜底", "先检查文件存在（预防），再用 try（兜底），两个都要。"),
                ],
                "tasks": [
                    "写一个读文件的函数，文件不存在时打印人话、返回 None",
                    "调用方检查 None，避免继续用",
                    "故意造一个空文件，看处理",
                    "把 except 写成具体异常类型",
                    "对比：不接住会怎样（把 try 删掉试一次）",
                ],
                "code": 'import os\n\n\ndef read_file(path):\n    if not os.path.exists(path):\n        print("找不到文件：", path)\n        return None\n    try:\n        with open(path, "r", encoding="utf-8") as f:\n            return f.readlines()\n    except OSError as e:\n        print("读取失败：", e)\n        return None\n\n\nlines = read_file("不存在.txt")\nif lines is None:\n    print("没有数据，退出")\nelse:\n    print("行数：", len(lines))',
                "check": [
                    "文件不存在时有提示、不崩",
                    "能说清 try/except 的作用",
                    "知道为什么必须检查 None",
                ],
            },
            {
                "d": 16,
                "title": "测试：把「对」写下来",
                "learn": "测试不是证明它对，是「以后你改坏了，它会告诉你」。用 Python 自带的 unittest，零安装。",
                "concepts": [
                    ("unittest", "Python 自带测试框架，不需要 pip install。"),
                    ("TestCase", "测试类要继承 unittest.TestCase。"),
                    ("test_ 开头", "方法名以 test_ 开头才会被执行。"),
                    ("assertEqual", "断言两个值相等。不等就报错。"),
                ],
                "tasks": [
                    "新建 analyze.py，写一个 analyze_one(path) 函数",
                    "新建 test_analyze.py，写 3 个测试",
                    "运行 python3 -m unittest test_analyze -v",
                    "故意改坏 analyze.py 里的一行，再跑测试，看到 FAILED",
                    "改回来，确认全绿",
                ],
                "code": 'import unittest\n\nfrom analyze import analyze_one   # 假设 analyze.py 里是这个函数\n\n\nclass AnalyzeTest(unittest.TestCase):\n\n    def test_normal(self):\n        # 这里用临时文件造数据，不要依赖外部文件\n        pass\n\n    def test_empty(self):\n        pass\n\n\nif __name__ == "__main__":\n    unittest.main()',
                "check": [
                    "3 个测试全过",
                    "故意改坏后能看到 FAILED",
                    "能说清 assertEqual 在干什么",
                ],
            },
            {
                "d": 17,
                "title": "调试：缩小范围，不要猜",
                "learn": "新手调试是「改一下跑一下」，老手是「先确定哪一段有问题」。调试三步法：复现 → 缩小 → 验证。",
                "concepts": [
                    ("复现", "让它每次都错。不能复现的 bug 修不了。"),
                    ("二分法", "注释掉一半代码，看还错不错，快速定位区间。"),
                    ("print 打点", "在关键位置打印变量的值和类型。新手最有效的工具。"),
                    ("阅读报错", "从最后一行往前读，找到你自己的那一行。"),
                ],
                "tasks": [
                    "造一个除零错误：print(1/0)，看报错",
                    "造一个 KeyError：取字典不存在的键",
                    "造一个 IndexError：取列表第 10 个元素",
                    "每修一个，写下「我是怎么定位的」",
                    "练一次二分法：把 50 行代码注释一半，找 bug",
                ],
                "code": '# 三个经典错误，逐个运行看报错，然后修好\n\n# 1. 除零\nprint(10 / 0)\n\n# 2. KeyError\nd = {"a": 1}\nprint(d["b"])\n\n# 3. IndexError\nitems = [1, 2, 3]\nprint(items[10])',
                "check": [
                    "能认出 ZeroDivisionError / KeyError / IndexError",
                    "能说出调试三步法",
                    "至少用二分法定位过一次问题",
                ],
            },
            {
                "d": 18,
                "title": "重构：把一坨拆成函数",
                "learn": "拆函数的标准不是「太长」，是「这件事有没有名字」。拆完的标志：改一处不影响别处。",
                "concepts": [
                    ("职责单一", "一个函数只做一件事。名字能准确概括它。"),
                    ("参数与返回", "函数通过参数拿输入、通过 return 给结果，不靠全局变量。"),
                    ("重构", "改结构不改行为。改完必须跑测试确认没坏。"),
                    ("为什么拆", "能单独测、能复用、改的时候影响面小。"),
                ],
                "tasks": [
                    "拿一段 40 行的「一坨」代码（可以自己写一个）",
                    "拆成 3 个函数：读取 / 处理 / 输出",
                    "每个函数写一句 docstring",
                    "改输出格式，确认处理逻辑一行都不用改",
                    "跑测试确认没坏",
                ],
                "code": 'def read_lines(path):\n    """读文件，返回行列表。"""\n    with open(path, "r", encoding="utf-8") as f:\n        return f.readlines()\n\n\ndef compute_stats(lines):\n    """统计总行数、空行数。"""\n    total = len(lines)\n    empty = sum(1 for line in lines if line.strip() == "")\n    return {"total": total, "empty": empty}\n\n\ndef print_stats(stats):\n    """打印统计结果。"""\n    print("总行数：", stats["total"])\n    print("空行数：", stats["empty"])',
                "check": [
                    "拆出 3 个职责单一的函数",
                    "改输出时没动处理逻辑",
                    "能说清为什么这么拆",
                ],
            },
            {
                "d": 19,
                "title": "模块与 import",
                "learn": "代码多了要分文件。import 就是「用别的文件里的东西」。",
                "concepts": [
                    ("模块", "一个 .py 文件就是一个模块。"),
                    ("import", "import math 用标准库；from analyze import f 用自己写的。"),
                    ("__name__", "if __name__ == \"__main__\": 表示「只有直接运行时才执行」。"),
                    ("包", "文件夹 + __init__.py 就是一个包。"),
                ],
                "tasks": [
                    "把之前的函数拆到 helper.py",
                    "在 main.py 里 import 它并调用",
                    "加 if __name__ == \"__main__\": 保护",
                    "试试直接运行 helper.py，看会不会执行测试代码",
                ],
                "code": '# helper.py\ndef double(x):\n    return x * 2\n\n\nif __name__ == "__main__":\n    # 只有直接运行 helper.py 时才执行\n    print(double(3))\n\n\n# main.py\n# from helper import double\n# print(double(5))',
                "check": [
                    "能拆文件并 import",
                    "知道 __name__ == \"__main__\" 的作用",
                    "知道包需要 __init__.py",
                ],
            },
            {
                "d": 20,
                "title": "Git：给代码留版本",
                "learn": "Git 让你能回到任何一个版本。改坏了不怕，这是你敢改的底气。",
                "concepts": [
                    ("git init", "在一个文件夹里初始化仓库。"),
                    ("git add / commit", "把改动加入暂存，然后提交一个版本。"),
                    ("git log", "看历史。"),
                    (".gitignore", "告诉 Git 哪些文件不要管（比如密钥、缓存）。"),
                ],
                "tasks": [
                    "在 ~/fde-code 下执行 git init",
                    "写一个 .gitignore（至少包含 .DS_Store 和 __pycache__/）",
                    "git add . && git commit -m \"第一周练习\"",
                    "改一个文件，git status 看变化",
                    "再 commit 一次，git log 看两条记录",
                ],
                "code": '# .gitignore 内容示例\n.DS_Store\n__pycache__/\n*.pyc\n.env\n*.log',
                "check": [
                    "能 init / add / commit / log",
                    "有 .gitignore",
                    "知道绝对不能提交密钥文件",
                ],
            },
            {
                "d": 21,
                "title": "周项目：给工具加测试和异常处理",
                "learn": "把前 6 天学的合起来：给你的 batch.py 加测试、加异常处理、加 Git 提交。",
                "concepts": [
                    ("测试覆盖", "至少覆盖：正常、空文件、文件不存在三种情况。"),
                    ("异常处理", "单个文件失败不能影响其他文件。"),
                    ("提交规范", "每次 commit 说清做了什么。"),
                ],
                "tasks": [
                    "给 batch.py 的 analyze_one 写 3 个测试",
                    "让 batch.py 遇到坏文件时跳过并记录，不整体崩",
                    "跑测试确认全绿",
                    "git commit 提交这一周成果",
                    "写本周 3 行日志",
                ],
                "code": '',
                "check": [
                    "测试全绿",
                    "坏文件不会导致整体崩",
                    "有至少 3 次 commit 记录",
                ],
            },
        ],
    },
    {
        "n": 4,
        "title": "做第一个真项目：字幕质检",
        "goal": "从零做出一个「能给别人用」的工具，包括解析、规则、报告、README。",
        "deliverable": "subtitle-qc v0.1：解析 SRT、5 条规则、生成 Markdown 报告、有 README",
        "days": [
            {
                "d": 22,
                "title": "认识你要处理的数据：SRT 字幕",
                "learn": "动手前先看懂数据格式。SRT 是影视交付里最常见的字幕格式，你必须能一眼看出结构。",
                "concepts": [
                    ("SRT 结构", "序号 / 时间轴 / 文本，每条之间空一行。"),
                    ("时间码", "00:00:01,000 --> 00:00:04,000，逗号后面是毫秒。"),
                    ("为什么转毫秒", "字符串没法算时长，转成毫秒数字才能比较和计算。"),
                ],
                "tasks": [
                    "建 ~/fde-code/subtitle-qc/",
                    "造 samples/good.srt（3 条正常字幕）",
                    "造 samples/bad.srt（含重叠、太短、超长）",
                    "用肉眼标出 bad.srt 里哪几条有问题",
                ],
                "code": '1\n00:00:01,000 --> 00:00:04,000\n你走的时候别回头\n\n2\n00:00:05,500 --> 00:00:09,200\n我在楼下等你',
                "check": [
                    "能说清 SRT 的三段结构",
                    "能在 bad.srt 里找出至少 3 个问题",
                ],
            },
            {
                "d": 23,
                "title": "写解析器",
                "learn": "解析 = 把文本变成结构化的数据。这是所有数据处理的第一步。",
                "concepts": [
                    ("split(\"\\n\\n\")", "按空行切块，每块是一条字幕。"),
                    ("时间解析", "把 00:00:01,000 拆成时、分、秒、毫秒，算出总毫秒。"),
                    ("数据结构", "每条变成 {\"index\", \"start\", \"end\", \"duration\", \"text\"}。"),
                ],
                "tasks": [
                    "写 subtitle_qc/parser.py",
                    "实现 parse_time(text)",
                    "实现 parse_srt(path)",
                    "用 good.srt 和 bad.srt 验证条数对不对",
                    "打印第一条，检查字段",
                ],
                "code": 'def parse_time(text):\n    hms, ms = text.split(",")\n    h, m, s = hms.split(":")\n    return int(h) * 3600000 + int(m) * 60000 + int(s) * 1000 + int(ms)\n\n\ndef parse_srt(path):\n    with open(path, "r", encoding="utf-8") as f:\n        content = f.read()\n\n    items = []\n    for block in content.strip().split("\\n\\n"):\n        lines = block.strip().split("\\n")\n        if len(lines) < 3 or "-->" not in lines[1]:\n            continue\n        start_str, end_str = lines[1].split("-->")\n        start = parse_time(start_str.strip())\n        end = parse_time(end_str.strip())\n        items.append({\n            "index": lines[0].strip(),\n            "start": start,\n            "end": end,\n            "duration": end - start,\n            "text": " ".join(l.strip() for l in lines[2:]),\n        })\n    return items',
                "check": [
                    "good.srt 解析出 3 条，bad.srt 解析出 4 条",
                    "能说清 duration 怎么算的",
                    "能为 parse_time 写测试",
                ],
            },
            {
                "d": 24,
                "title": "写质检规则",
                "learn": "每条规则 = 一个判断函数 + 一个业务理由。这是你的行业知识变现的地方。",
                "concepts": [
                    ("重叠", "后一条的开始时间 < 前一条的结束时间。"),
                    ("CPS", "每秒字数 = 字数 / 秒数。超过 20 观众读不完。"),
                    ("行长", "中文单行超过 20 字会被裁切。"),
                    ("严重度", "high 必须改，medium 建议改。交付时客户最关心这个。"),
                ],
                "tasks": [
                    "写 rules.py，实现 5 条规则：重叠、太短、超长、太快、空文本",
                    "写 run_all(items) 跑全部规则",
                    "对 bad.srt 跑一遍，看报了几个",
                    "逐条判断「它报得对吗」",
                    "给每条规则写一句「为什么」",
                ],
                "code": 'def check_overlap(items):\n    problems = []\n    for i in range(1, len(items)):\n        prev, cur = items[i - 1], items[i]\n        if cur["start"] < prev["end"]:\n            problems.append({\n                "type": "overlap",\n                "index": cur["index"],\n                "detail": "和第 %s 条重叠 %d 毫秒" % (prev["index"], prev["end"] - cur["start"]),\n                "level": "high",\n            })\n    return problems\n\n\ndef check_cps(items, max_cps=20):\n    problems = []\n    for it in items:\n        seconds = it["duration"] / 1000.0\n        if seconds <= 0:\n            continue\n        cps = len(it["text"]) / seconds\n        if cps > max_cps:\n            problems.append({\n                "type": "too_fast",\n                "index": it["index"],\n                "detail": "每秒 %.1f 字" % cps,\n                "level": "high",\n            })\n    return problems',
                "check": [
                    "5 条规则能跑",
                    "每条规则能说清业务理由",
                    "能判断 bad.srt 的报出结果对不对",
                ],
            },
            {
                "d": 25,
                "title": "生成报告",
                "learn": "交付物不是终端里的一堆字，是一份能发给客户的报告。",
                "concepts": [
                    ("Markdown", "用 # 标题、| 表格 | 表示格式，纯文本但能渲染。"),
                    ("报告结构", "文件信息 / 结论 / 问题清单。"),
                    ("写入文件", "用 \"w\" 模式，会覆盖同名文件。"),
                ],
                "tasks": [
                    "写 report.py 的 build_report()",
                    "生成 Markdown 报告",
                    "写 main.py 串起来：解析 → 跑规则 → 出报告",
                    "跑 bad.srt，打开报告看",
                    "跑 good.srt，确认写「未发现问题」",
                ],
                "code": 'def build_report(path, items, problems):\n    high = [p for p in problems if p["level"] == "high"]\n    lines = ["# 字幕质检报告", "", "- 文件：%s" % path, "- 条目数：%d" % len(items), ""]\n    if not problems:\n        lines.append("未发现问题。")\n    else:\n        lines.append("发现 **%d** 个问题，其中 **%d** 个必须修改。" % (len(problems), len(high)))\n    lines += ["", "| 严重度 | 条目 | 类型 | 说明 |", "|---|---|---|---|"]\n    for p in problems:\n        lines.append("| %s | %s | %s | %s |" % (p["level"], p["index"], p["type"], p["detail"]))\n    return "\\n".join(lines)',
                "check": [
                    "能生成 report.md",
                    "bad.srt 报告至少 3 个问题",
                    "good.srt 写「未发现问题」",
                ],
            },
            {
                "d": 26,
                "title": "写 README（别人的入口）",
                "learn": "没有 README 的东西，等于没做。别人不知道怎么用，就不会用。",
                "concepts": [
                    ("README 五部分", "做什么 / 怎么用 / 输出什么 / 检查什么 / 已知限制。"),
                    ("已知限制", "主动写「它会在哪坏」，比写「它多牛」更能建立信任。"),
                    ("可复现", "陌生人照 README 能跑起来，才算交付。"),
                ],
                "tasks": [
                    "写 README.md，包含五部分",
                    "找一个不懂编程的人，让他照 README 跑一次",
                    "记录他卡在哪",
                    "根据卡点改 README",
                ],
                "code": '# 字幕质检工具\n\n## 做什么\n读一个字幕文件，检查 5 类问题，生成报告。\n\n## 怎么用\n    python3 main.py samples/bad.srt\n\n## 检查什么\n1. 时间轴重叠\n2. 单条太短（<0.8 秒）\n3. 单行太长（>20 字）\n4. 阅读速度太快（>20 字/秒）\n5. 空文本\n\n## 已知限制\n- 只支持 .srt\n- 阈值写死在代码里',
                "check": [
                    "README 五部分齐全",
                    "有真人照 README 跑通过",
                    "记录了对方卡在哪",
                ],
            },
            {
                "d": 27,
                "title": "关掉 AI，重写核心函数",
                "learn": "今天是检验：你到底学会了没有。重写 parse_srt，限时 60 分钟。",
                "concepts": [
                    ("默写检验", "不看代码、不查资料，从空白写。写不出来的地方就是没学会。"),
                    ("卡点记录", "每卡一次记一笔，那是你的学习地图。"),
                ],
                "tasks": [
                    "关掉 AI、关掉之前的代码",
                    "从空白重写 parse_time 和 parse_srt",
                    "限时 60 分钟",
                    "写完对照原版，找出 3 个差异",
                    "把卡住的地方写成清单",
                ],
                "code": '',
                "check": [
                    "60 分钟内写出能跑的版本（哪怕不完整）",
                    "有 3 条以上卡点记录",
                    "能说出自己和原版的差异",
                ],
            },
            {
                "d": 28,
                "title": "第一次「交付」",
                "learn": "把你的工具发给一个真人用。这是你从「自己做着玩」到「交付」的分界线。",
                "concepts": [
                    ("交付", "别人能用起来，才叫交付。自己能跑不算。"),
                    ("问对问题", "不要问「怎么样」，要问「哪里最没用」。"),
                    ("收反馈", "记录原话，不要美化。"),
                ],
                "tasks": [
                    "把 subtitle-qc 发给一个前同事/行业朋友",
                    "话术：我做了个字幕质检工具，你手上有没有交付过的字幕，我免费帮你跑一份报告",
                    "记录他的原话",
                    "记录他卡在哪",
                    "根据反馈改一处",
                ],
                "code": '',
                "check": [
                    "发出去了",
                    "有真实反馈记录",
                    "改了至少一处",
                ],
            },
        ],
    },
    {
        "n": 5,
        "title": "评测：证明它有用（最重要）",
        "goal": "给你的工具建立评测集，算出检出率、误报、耗时。这是你和「只会做 demo 的人」的分水岭。",
        "deliverable": "一份带数字的评测报告 + badcase 归因",
        "days": [],
    },
    {
        "n": 6,
        "title": "做得更专业：配置、日志、多格式",
        "goal": "让工具能适配不同客户：阈值可配置、有日志、支持 .ass、批量、失败不崩。",
        "deliverable": "subtitle-qc v1.0：可配置、有日志、支持多格式、有运行摘要",
        "days": [],
    },
    {
        "n": 7,
        "title": "加 AI：翻译与术语一致性",
        "goal": "接大模型做翻译，用代码做术语校验，算清成本，处理失败。",
        "deliverable": "带 AI 翻译和术语校验的 v1.5，有成本和失败兜底",
        "days": [],
    },
    {
        "n": 8,
        "title": "上云：让别人点开就能用",
        "goal": "把工具包成 Web 服务，Docker 化，部署上线，加日志和监控。",
        "deliverable": "一个能访问的地址 + runbook",
        "days": [],
    },
    {
        "n": 9,
        "title": "交付：文档、演示、交接",
        "goal": "写交付四件套，录 3 分钟演示，找 2 个真人用。",
        "deliverable": "README + 架构图 + runbook + 已知限制 + demo 视频",
        "days": [],
    },
    {
        "n": 10,
        "title": "读透一个陌生系统（SkillRadar）",
        "goal": "用 5 步法读你自己那个 AI 写的 1.1 万行系统，找到 3 处静默出错的地方。",
        "deliverable": "能讲 30 分钟的深度案例 + 交接文档",
        "days": [],
    },
    {
        "n": 11,
        "title": "写成案例，准备面试",
        "goal": "写 3 个案例、中英简历、8 个 STAR 故事，练 3 道送命题。",
        "deliverable": "3 个案例 + 简历 + 模拟面试记录",
        "days": [],
    },
    {
        "n": 12,
        "title": "打包投递",
        "goal": "GitHub、作品集、投 3 个岗位、写下一个 90 天计划。",
        "deliverable": "可公开的作品集 + 投递记录",
        "days": [],
    },
]

# 周 5 之后只给目标与关键动作（不拆到天）
WEEK_DETAIL = {
    5: [
        "D1 造 20 条黄金集：人工标出每条字幕该报什么问题（至少 5 条故意没问题）",
        "D2 写评测脚本：一条命令算出命中/漏报/误报/检出率",
        "D3 逐条分析 badcase：每条写清「为什么漏/为什么误报」",
        "D4 版本对比：改一个阈值，做对比表，判断「这版值不值得上」",
        "D5 把评测数字写进 README",
        "D6 诚实检查：我的测试集是不是太简单？换真实字幕会掉多少？",
        "D7 复盘：写下「评测让我第一次看到什么」",
    ],
    6: [
        "D1 阈值外置到 config.json，命令行可覆盖",
        "D2 加 logging，替换所有 print，输出到 run.log",
        "D3 支持 .ass 格式（时间格式和 SRT 不同）",
        "D4 支持传文件夹批量处理，出汇总报告",
        "D5 失败重试 + 先写 tmp 再 os.replace，不留半成品",
        "D6 每次运行输出「运行摘要」：处理几个/成功几个/失败几个/耗时",
        "D7 复盘：给新功能补测试，测试总数 ≥12",
    ],
    7: [
        "D1 第一次调用大模型 API（Key 存环境变量，绝不写进代码）",
        "D2 用结构化输出约束模型，要求只返回 JSON，解析失败要重试",
        "D3 术语表机制：提示词约束 + 代码二次校验",
        "D4 成本核算：记录 token、算每条多少钱",
        "D5 四种失败兜底：超时/限流/格式错/内容被拒",
        "D6 用 mock 给 AI 部分写测试（不真的联网）",
        "D7 复盘：AI 部分哪里最容易出错",
    ],
    8: [
        "D1 用 FastAPI 暴露 POST /qc 和 GET /health",
        "D2 写 Dockerfile，镜像能起来",
        "D3 部署到云服务器或内网穿透，有可访问地址",
        "D4 加请求日志和 /metrics（请求数/失败数/平均耗时）",
        "D5 故障演练：删 Key、传空文件、磁盘满，逐个定位",
        "D6 写 runbook：启动/重启/回滚/查日志",
        "D7 复盘：本地能跑和线上能用的差别",
    ],
    9: [
        "D1 写 README（5 分钟能跑起来）",
        "D2 画架构图，标出人工介入点",
        "D3 写 RUNBOOK 和 LIMITATIONS（至少 5 条）",
        "D4 录 3 分钟 demo：痛点→方案→演示→数字→取舍→限制",
        "D5 发给 2 个真人用，记录反馈",
        "D6 根据反馈改，写 DELIVERY.md 交付复盘",
        "D7 复盘：用户最在意的和我以为的一样吗",
    ],
    10: [
        "D1 找入口：cli.py 的 main 支持哪些子命令",
        "D2 追一条数据流：GitHub API → 数据库 → 报告，画出图",
        "D3 审计 scoring.py：六个维度怎么算、许可证硬门槛在哪",
        "D4 找 3 处「静默出错」的地方（db.py 事务边界是一个）",
        "D5 画模块依赖图，找出被依赖最多和最乱的",
        "D6 写 HANDOVER.md 交接文档",
        "D7 对着屏幕讲 30 分钟并录音，回听标记卡点",
    ],
    11: [
        "D1 写主案例：subtitle-qc（问题→方案→取舍→数字→限制）",
        "D2 写深度案例：我读了一个 AI 写的系统",
        "D3 写第三案例：GOKU 交接包（证明会管上下文）",
        "D4 写简历（一页，每个项目带数字）",
        "D5 准备 8 个 STAR 故事，每个 60–90 秒",
        "D6 练 3 道送命题：没工程经验 / 代码是 AI 写的 / 年龄",
        "D7 模拟面试 45 分钟，记录被问住的问题",
    ],
    12: [
        "D1 整理 GitHub 仓库，README 加演示和数字",
        "D2 做一页作品集索引（3 个项目 + 链接）",
        "D3 发给 5 个人，问「哪里最没用」",
        "D4 投 3 个岗位，记录反馈",
        "D5 复盘 12 周：能做什么、短板是什么、下一步学什么",
        "D6 写下一个 90 天计划（3 个目标，每个有衡量标准）",
        "D7 休整 + 决定：接单还是投简历",
    ],
}

# ============================================================
# 扫盲知识库
# ============================================================

CONCEPTS = [
    ("电脑只会三件事", "搬数据、算数、按条件跳转。所有程序都是这三件事的组合。"),
    ("程序", "一串按顺序执行的指令。电脑不猜你的意思，只照着做。"),
    ("源代码 vs 可执行", "你写的 .py 是人看的；解释器把它翻译成机器能执行的动作。"),
    ("变量", "给一个值起个名字。a = 1 意思是「把 1 叫做 a」。"),
    ("类型", "数据的形状：文字（str）、整数（int）、小数（float）、真假（bool）、列表（list）、字典（dict）。"),
    ("函数", "给一段代码起名字，可以反复调用。通过参数拿输入，通过 return 给结果。"),
    ("参数 / 返回值", "参数是函数的输入，返回值是输出。不写 return 就返回 None。"),
    ("模块 / 包", "一个 .py 文件是模块；一个带 __init__.py 的文件夹是包。"),
    ("import", "使用别的文件里的东西。import math 用标准库，from x import y 用自己写的。"),
    ("异常", "程序出错时抛出的信号。try/except 可以接住，不让程序崩。"),
    ("测试", "把「输入 X 应该得到 Y」写成代码。价值在「你改坏了它告诉你」。"),
    ("调试", "先复现、再缩小范围、最后写测试验证。不是猜。"),
    ("重构", "改结构不改行为。拆函数的标准是「这件事有没有名字」。"),
    ("API", "别人给你留的「窗口」，你按格式发请求，它按格式回数据。"),
    ("HTTP", "浏览器和服务器说话的方式。GET 取数据，POST 提交数据，200 成功，404 找不到。"),
    ("JSON", "最常见的结构化数据格式。{\"键\": 值}。对应 Python 的 dict。"),
    ("数据库", "存数据的地方。SQL 是跟它说话的语言。表 = 一类数据，行 = 一条记录。"),
    ("SQL", "SELECT（查）/ INSERT（加）/ UPDATE（改）/ DELETE（删）。JOIN 把两张表连起来。"),
    ("命令行 / 终端", "用文字给电脑下命令的窗口。不是黑魔法。"),
    ("路径", "文件在电脑里的地址。/Users/xxx/文件 是绝对路径，./文件 是相对当前目录。"),
    ("Git", "给代码留版本。能回到任何一个版本，这是你敢改的底气。"),
    ("部署", "把程序放到一台别人也能访问的机器上。"),
    ("Docker", "把程序和环境打包成一个「集装箱」，到哪都能跑。"),
    ("日志", "程序运行时记下「发生了什么」。出问题靠它定位。"),
    ("指标", "能被人用来做决定的数字。比如「检出率 85%」。"),
    ("LLM / 大模型", "能理解和生成文字的模型。你给它文字，它给你文字。"),
    ("提示词", "你给模型的指令。说得越清楚、约束越明确，输出越稳定。"),
    ("Token", "模型计费的单位，也是它一次能处理的文字量单位。"),
    ("RAG", "先检索资料，再把资料给模型，让它基于资料回答。解决「模型不知道你的数据」。"),
    ("Agent", "能自己决定调用哪些工具、分几步完成任务的程序。"),
    ("评测 / Eval", "用一批已知答案的数据，算出系统的准确率。"),
    ("幻觉", "模型编出看起来对、其实错的内容。"),
    ("FDE", "被派到客户现场，把模型能力变成客户流程里真实在跑的东西，并对结果负责的工程师。"),
]

QUIZ = [
    {"q": "程序本质上是什​么？", "a": ["一堆按顺序执行的指令", "一种数据库", "一种设计图", "一种网页"], "ok": 0,
     "why": "程序就是指令序列。电脑不会猜你的意思。"},
    {"q": "a = 1 是什么意思？", "a": ["a 等于 1，永远不变", "把 1 这个值叫做 a", "比较 a 和 1", "创建一个文件"], "ok": 1,
     "why": "变量是「给值起名字」，之后 a 还可以被改成别的值。"},
    {"q": "print 和 return 的区别？", "a": ["没区别", "print 给人看，return 给程序用", "return 更快", "print 只能在函数里用"], "ok": 1,
     "why": "混了就会出 bug：函数只 print 不 return，调用方拿到的是 None。"},
    {"q": "为什么判断空行要用 line.strip() == \"\"？", "a": ["因为 strip 更快", "因为空行读出来是 \"\\n\" 不是 \"\"", "因为 Python 要求", "因为 strip 会删除行"], "ok": 1,
     "why": "文件里的空行是换行符，strip() 去掉后才等于空字符串。"},
    {"q": "字典取值用 [] 还是 get()？", "a": ["永远用 []", "数据可能缺字段时用 get()", "get() 更快", "没区别"], "ok": 1,
     "why": "真实数据经常缺字段。[] 会报 KeyError，get() 可以给默认值。"},
    {"q": "测试最大的价值是什么？", "a": ["证明代码写得对", "通过公司检查", "你改坏时它告诉你", "让代码跑得更快"], "ok": 2,
     "why": "测试是回归防线，不是一次性验收。"},
    {"q": "看到 Traceback 应该先看什么？", "a": ["第一行", "最后一行和 File/line", "中间一大段", "不用看"], "ok": 1,
     "why": "最后一行是错误类型和原因，File/line 告诉你在哪。"},
    {"q": "JSON 的 null 对应 Python 的什么？", "a": ["0", "空字符串", "None", "False"], "ok": 2,
     "why": "null = 没有值 = None。"},
    {"q": "CSV 读出来的数字是什么类型？", "a": ["int", "float", "字符串", "自动识别"], "ok": 2,
     "why": "CSV 全是字符串，要 int() 转换才能比较大小。"},
    {"q": "FDE 和产品经理最大的差别？", "a": ["FDE 更懂业务", "FDE 自己动手实现", "FDE 不出差", "没差别"], "ok": 1,
     "why": "产品经理说「交给研发」，FDE 说「我做出来了，你试试」。"},
]

# ============================================================
# 生成 HTML
# ============================================================

DATA = {
    "weeks": WEEKS,
    "weekDetail": {str(k): v for k, v in WEEK_DETAIL.items()},
    "concepts": CONCEPTS,
    "quiz": QUIZ,
}

payload = json.dumps(DATA, ensure_ascii=False)
payload = payload.replace("</", "<\\/")

HTML = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FDE 学习台 · 本地版</title>
<style>
:root{
  --bg:#0a0d12;--bg2:#11161f;--panel:#151b26;--line:#232c3b;
  --ink:#e8edf5;--muted:#8b97a8;--dim:#5c6779;
  --amber:#f0b429;--cyan:#38bdf8;--green:#34d399;--red:#f87171;--violet:#a78bfa;
  --r:14px;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--ink);font-family:"PingFang SC","Hiragino Sans GB","Microsoft YaHei",-apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif;line-height:1.7;font-size:15px;-webkit-font-smoothing:antialiased}
button{font-family:inherit}
a{color:var(--cyan);text-decoration:none}
.wrap{max-width:1080px;margin:0 auto;padding:0 20px}

header{position:sticky;top:0;z-index:50;background:rgba(10,13,18,.94);backdrop-filter:blur(14px);border-bottom:1px solid var(--line);overflow:hidden}
.hrow{display:flex;align-items:center;gap:14px;padding:11px 0;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;cursor:pointer}
.logo{width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,var(--amber),#d97706);display:grid;place-items:center;font-size:14px;color:#0a0d12;font-weight:900}
.brand small{display:block;font-size:10px;color:var(--muted);font-weight:400;letter-spacing:1.4px;margin-top:-4px}
nav{display:flex;gap:3px;margin-left:auto;flex-wrap:nowrap;overflow-x:auto;max-width:100%;-webkit-overflow-scrolling:touch;scrollbar-width:none}
  nav::-webkit-scrollbar{display:none}
  .hrow{min-width:0}
  body{overflow-x:hidden}
.tab{background:transparent;border:1px solid transparent;color:var(--muted);padding:6px 11px;border-radius:9px;cursor:pointer;font-size:13px;transition:.15s}
.tab:hover{color:var(--ink);background:var(--panel)}
.tab.on{color:#0a0d12;background:var(--amber);font-weight:700}

main{padding:24px 0 50px}
section{display:none;animation:fade .2s ease}
section.on{display:block}
@keyframes fade{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}

.card{background:var(--panel);border:1px solid var(--line);border-radius:var(--r);padding:20px;margin-bottom:14px}
h2{font-size:19px;margin-bottom:12px}
h3{font-size:15.5px;margin-bottom:10px}
h4{font-size:13.5px;margin-bottom:8px;color:var(--cyan)}
.muted{color:var(--muted)}.dim{color:var(--dim)}.small{font-size:12.5px}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
.chip{display:inline-block;padding:2px 9px;border-radius:99px;font-size:11.5px;border:1px solid var(--line);color:var(--muted);margin:2px 5px 2px 0}
.chip.a{border-color:#5b4a1a;color:var(--amber);background:#1e1a10}
.chip.c{border-color:#164e63;color:var(--cyan);background:#0d2430}
.chip.g{border-color:#14532d;color:var(--green);background:#0d2419}
.chip.r{border-color:#7f1d1d;color:var(--red);background:#2a1213}

.bar{height:8px;background:#0b0f16;border-radius:99px;overflow:hidden;border:1px solid var(--line)}
.bar>i{display:block;height:100%;background:linear-gradient(90deg,var(--amber),#fbbf24);transition:width .4s}
.bar.c>i{background:linear-gradient(90deg,var(--cyan),#67e8f9)}
.bar.g>i{background:linear-gradient(90deg,var(--green),#6ee7b7)}

.grid{display:grid;gap:12px}
.g2{grid-template-columns:1fr 1fr}
.g3{grid-template-columns:repeat(3,1fr)}
.g4{grid-template-columns:repeat(4,1fr)}
@media(max-width:820px){.g2,.g3,.g4{grid-template-columns:1fr}.g4{grid-template-columns:1fr 1fr}.card{padding:16px}.wrap{padding:0 14px}}

.stat{background:var(--bg2);border:1px solid var(--line);border-radius:12px;padding:14px}
.stat b{display:block;font-size:24px;font-family:ui-monospace,monospace;color:var(--amber);line-height:1.2}
.stat span{font-size:11.5px;color:var(--muted)}
.stat .sub{font-size:11px;color:var(--dim);margin-top:4px}

.btn{background:var(--bg2);border:1px solid var(--line);color:var(--ink);padding:8px 16px;border-radius:9px;font-size:13.5px;cursor:pointer;transition:.15s}
.btn:hover{border-color:var(--amber);color:var(--amber)}
.btn.primary{background:var(--amber);border-color:var(--amber);color:#0a0d12;font-weight:700}
.btn.primary:hover{background:#fbbf24;color:#0a0d12}
.btn.sm{padding:5px 11px;font-size:12px}
.btn.ghost{background:transparent}

/* 周卡片 */
.week{background:var(--bg2);border:1px solid var(--line);border-radius:13px;padding:16px;margin-bottom:10px;cursor:pointer;transition:.15s}
.week:hover{border-color:#3a4757}
.week.done{border-color:#14532d;background:#0d1a14}
.week.cur{border-color:var(--amber);box-shadow:0 0 0 1px rgba(240,180,41,.25)}
.week .wh{display:flex;align-items:center;gap:10px;margin-bottom:5px}
.week .wn{font-family:ui-monospace,monospace;font-size:11.5px;color:var(--amber);letter-spacing:1px}
.week .wt{font-size:16px;font-weight:700}
.week .wmeta{font-size:11.5px;color:var(--dim);margin-left:auto;font-family:ui-monospace,monospace}
.week .wg{font-size:12.5px;color:var(--muted);margin-bottom:9px}
.week .wfoot{display:flex;align-items:center;gap:10px}
.week .wfoot .bar{flex:1}

/* 天 */
.day{background:var(--bg2);border:1px solid var(--line);border-radius:12px;margin-bottom:10px;overflow:hidden}
.day .dh{display:flex;align-items:center;gap:10px;padding:13px 15px;cursor:pointer}
.day .dh:hover{background:#171e29}
.day .dn{font-family:ui-monospace,monospace;font-size:11px;color:var(--amber);letter-spacing:.5px;min-width:34px}
.day .dt{font-size:14.5px;font-weight:600;flex:1}
.day .dck{width:20px;height:20px;border-radius:50%;border:1.5px solid var(--line);display:grid;place-items:center;font-size:11px;color:transparent;flex:none}
.day.done .dck{background:var(--green);border-color:var(--green);color:#04120b}
.day .body{display:none;padding:0 15px 16px;border-top:1px solid var(--line)}
.day.open .body{display:block}
.day .body>div{margin-top:14px}
.learn{background:#0d1a24;border-left:2px solid var(--cyan);padding:11px 13px;border-radius:0 8px 8px 0;font-size:13.5px;color:#c9dbe8}
.concepts{display:grid;gap:7px}
.con{font-size:13px;color:var(--muted);padding-left:12px;border-left:1px solid var(--line)}
.con b{color:var(--ink)}
.tasks{list-style:none;display:grid;gap:6px}
.tasks li{font-size:13px;color:var(--muted);display:flex;gap:8px;align-items:flex-start}
.tasks li::before{content:"☐";color:var(--amber);flex:none}
.codebox{position:relative;background:#080b10;border:1px solid var(--line);border-radius:10px;overflow:hidden}
.codebox pre{padding:13px 14px;overflow-x:auto;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12.5px;line-height:1.65;color:#c8d4e2;white-space:pre}
.codebox .cp{position:absolute;top:7px;right:7px;background:#1b2432;border:1px solid var(--line);color:var(--muted);font-size:11px;padding:3px 9px;border-radius:6px;cursor:pointer}
.codebox .cp:hover{color:var(--amber);border-color:var(--amber)}
.check{list-style:none;display:grid;gap:5px}
.check li{font-size:13px;color:var(--muted);display:flex;gap:8px}
.check li::before{content:"✓";color:var(--green);flex:none}

/* 知识库 */
.concept{background:var(--bg2);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.concept b{display:block;font-size:13.5px;color:var(--amber);margin-bottom:4px}
.concept p{font-size:12.5px;color:var(--muted)}
.searchbox{width:100%;background:var(--bg2);border:1px solid var(--line);color:var(--ink);padding:11px 14px;border-radius:10px;font-size:14px;font-family:inherit;outline:none}
.searchbox:focus{border-color:var(--amber)}

/* 测验 */
.q{background:var(--bg2);border:1px solid var(--line);border-radius:11px;padding:15px;margin-bottom:10px}
.q .qt{font-size:14px;font-weight:600;margin-bottom:10px}
.opt{display:block;width:100%;text-align:left;background:#0b0f16;border:1px solid var(--line);color:var(--muted);padding:9px 12px;border-radius:8px;font-size:13px;margin-bottom:6px;cursor:pointer;transition:.12s}
.opt:hover{border-color:#3a4757;color:var(--ink)}
.opt.right{border-color:var(--green);background:#0d1a14;color:var(--green)}
.opt.wrong{border-color:var(--red);background:#1a0d0d;color:var(--red)}
.why{font-size:12.5px;color:var(--cyan);margin-top:8px;display:none}
.why.show{display:block}

footer{border-top:1px solid var(--line);padding:18px 0 30px;display:flex;gap:12px;flex-wrap:wrap;align-items:center;font-size:12px;color:var(--dim)}
.toast{position:fixed;bottom:22px;left:50%;transform:translateX(-50%) translateY(20px);background:var(--green);color:#04120b;padding:9px 18px;border-radius:99px;font-size:13px;font-weight:700;opacity:0;pointer-events:none;transition:.25s;z-index:99}
.toast.on{opacity:1;transform:translateX(-50%) translateY(0)}
.empty{text-align:center;color:var(--dim);padding:26px;font-size:13px}
</style>
</head>
<body>

<header>
  <div class="wrap hrow">
    <div class="brand" onclick="show('home')">
      <div class="logo">F</div>
      <div>FDE 学习台<small>LOCAL · OFFLINE</small></div>
    </div>
    <nav id="nav">
      <button class="tab on" data-t="home">首页</button>
      <button class="tab" data-t="course">12 周课程</button>
      <button class="tab" data-t="concepts">扫盲知识库</button>
      <button class="tab" data-t="quiz">测验</button>
      <button class="tab" data-t="ref">速查卡</button>
      <button class="tab" data-t="progress">我的进度</button>
    </nav>
  </div>
</header>

<main class="wrap">

  <!-- 首页 -->
  <section id="home" class="on"></section>

  <!-- 课程 -->
  <section id="course"></section>

  <!-- 扫盲 -->
  <section id="concepts">
    <h2>扫盲知识库 · <span class="small muted">33 个概念，先看懂再说</span></h2>
    <input class="searchbox" id="search" placeholder="搜一个词，比如「函数」「API」「评测」……" />
    <div class="grid g2" id="conceptList" style="margin-top:14px"></div>
  </section>

  <!-- 测验 -->
  <section id="quiz"></section>

  <!-- 速查卡 -->
  <section id="ref"></section>

  <!-- 进度 -->
  <section id="progress"></section>

</main>

<footer class="wrap">
  <span>FDE 学习台 · 本地版</span>
  <span class="dim">进度存在这台电脑的浏览器里，不上传</span>
  <button class="btn sm" id="export">导出进度</button>
  <button class="btn sm" id="import">导入进度</button>
  <button class="btn sm" id="reset">重置</button>
</footer>

<div class="toast" id="toast"></div>

<script>
const DATA = __PAYLOAD__;

/* ---------------- 状态 ---------------- */
const KEY = "fde_app_v1";
let S = load();
function load(){
  try{ const r = localStorage.getItem(KEY); if(r) return JSON.parse(r); }catch(e){}
  return { done:{}, quiz:{}, openWeeks:{}, started: todayStr() };
}
function save(){ try{ localStorage.setItem(KEY, JSON.stringify(S)); }catch(e){} }
function todayStr(){ const d=new Date(); return d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate(); }
function toast(m){ const t=document.getElementById("toast"); t.textContent=m; t.classList.add("on"); setTimeout(()=>t.classList.remove("on"),1600); }

/* ---------------- 计算 ---------------- */
function allDays(){
  const out = [];
  DATA.weeks.forEach(w=>{
    (w.days||[]).forEach(d=>out.push({week:w.n, day:d.d, title:d.title, data:d}));
  });
  return out;
}
function totalDays(){ return allDays().length; }
function doneCount(){ return Object.keys(S.done).filter(k=>S.done[k]).length; }
function pct(){ const t=totalDays(); return t? Math.round(doneCount()/t*100):0; }
function currentDay(){
  return allDays().find(d=>!S.done[dayKey(d)]) || null;
}
function dayKey(d){ return "w"+d.week+"d"+d.day; }
function weekProgress(w){
  const ds = w.days||[];
  if(!ds.length) return 0;
  const done = ds.filter(d=>S.done["w"+w.n+"d"+d.d]).length;
  return Math.round(done/ds.length*100);
}

/* ---------------- 渲染：首页 ---------------- */
function renderHome(){
  const cur = currentDay();
  const t = totalDays();
  const p = pct();
  const el = document.getElementById("home");

  let curHtml = "";
  if(cur){
    curHtml = `
      <div class="card" style="border-color:var(--amber)">
        <div class="small" style="color:var(--amber);letter-spacing:1px;margin-bottom:6px">今天从这里开始</div>
        <h2 style="margin-bottom:6px">第 ${cur.week} 周 · 第 ${cur.day} 天：${cur.title}</h2>
        <p class="muted small" style="margin-bottom:14px">${cur.data.learn.slice(0,90)}…</p>
        <button class="btn primary" onclick="openDay(${cur.week},${cur.day})">打开这一天的课 →</button>
      </div>`;
  } else {
    curHtml = `<div class="card" style="border-color:var(--green)">
      <h2 style="color:var(--green)">前 4 周已经全部完成 ✓</h2>
      <p class="muted small">接下来从第 5 周开始：评测。这是整条路线里最值钱的一周。</p>
      <button class="btn primary" style="margin-top:12px" onclick="show('course')">看第 5 周任务 →</button>
    </div>`;
  }

  el.innerHTML = `
    <div class="grid g4" style="margin-bottom:16px">
      <div class="stat"><b>${p}%</b><span>课程完成度</span><div class="sub">${doneCount()} / ${t} 天</div></div>
      <div class="stat"><b>${cur?cur.week:"—"}</b><span>当前周</span><div class="sub">${cur?"第 "+cur.day+" 天":"全部完成"}</div></div>
      <div class="stat"><b>${Object.keys(S.quiz).filter(k=>S.quiz[k]).length}/${DATA.quiz.length}</b><span>测验答对</span><div class="sub">概念检查</div></div>
      <div class="stat"><b>${daysSince()}</b><span>开始至今（天）</span><div class="sub">${S.started}</div></div>
    </div>

    ${curHtml}

    <div class="card">
      <h3>这门课怎么用（三句话）</h3>
      <div class="grid g3" style="margin-top:10px">
        <div class="stat"><b style="font-size:16px;color:var(--cyan)">① 每天只做一天</b><span>打开当天，照着敲，不要往下翻</span></div>
        <div class="stat"><b style="font-size:16px;color:var(--cyan)">② 关掉 AI 写代码</b><span>前 9 周不用 AI，练的是「能看出错」</span></div>
        <div class="stat"><b style="font-size:16px;color:var(--cyan)">③ 卡 30 分钟就跳过</b><span>记下来，周末集中解决</span></div>
      </div>
    </div>

    <div class="card">
      <h3>12 周路线（点开看每周）</h3>
      <div class="grid g2" style="margin-top:10px">
        ${DATA.weeks.map(w=>`
          <div class="week ${weekProgress(w)===100?"done":""} ${cur&&cur.week===w.n?"cur":""}" onclick="show('course');setTimeout(()=>jumpWeek(${w.n}),60)">
            <div class="wh"><span class="wn">W${w.n}</span><span class="wt">${w.title}</span>
              <span class="wmeta">${weekProgress(w)}%</span></div>
            <div class="wg">${w.goal}</div>
            <div class="bar ${weekProgress(w)===100?'g':''}"><i style="width:${weekProgress(w)}%"></i></div>
          </div>`).join("")}
      </div>
    </div>

    <div class="card">
      <h3>现实提醒</h3>
      <p class="small muted">
        12 周学完，<b style="color:var(--ink)">不会自动拿到 offer</b>。你会拿到的是：有一个能演示的作品、能讲清取舍、能扛住技术追问。<br/>
        真实路径：学完 → 有作品 → 有人愿意见你 → 面 3–5 家 → 拿 1 个 offer。offer 在第 4–6 个月。
      </p>
    </div>
  `;
}
function daysSince(){
  const s = new Date(S.started);
  const d = Math.floor((Date.now()-s.getTime())/86400000);
  return d<0?0:d;
}

/* ---------------- 渲染：课程 ---------------- */
function renderCourse(){
  const el = document.getElementById("course");
  el.innerHTML = `<h2>12 周课程</h2>
    <p class="small muted" style="margin-bottom:14px">前 4 周拆到每天（可直接照着做）；第 5–12 周给每周任务清单。点周展开，点天看内容。</p>
    <div id="weekList"></div>`;

  const box = document.getElementById("weekList");
  DATA.weeks.forEach(w=>{
    const p = weekProgress(w);
    const expanded = S.openWeeks[w.n] !== false;
    const wrap = document.createElement("div");
    wrap.id = "week-"+w.n;
    wrap.innerHTML = `
      <div class="week ${p===100?"done":""}" onclick="toggleWeek(${w.n})">
        <div class="wh"><span class="wn">W${w.n}</span><span class="wt">${w.title}</span>
          <span class="wmeta">${w.days&&w.days.length? (w.days.filter(d=>S.done["w"+w.n+"d"+d.d]).length+"/"+w.days.length+" 天") : "任务清单"} · ${p}%</span></div>
        <div class="wg">${w.goal}</div>
        <div class="bar ${p===100?'g':''}"><i style="width:${p}%"></i></div>
        <div class="small dim" style="margin-top:8px">交付：${w.deliverable}</div>
      </div>
      <div id="days-${w.n}" style="display:${expanded?"block":"none"};padding-left:8px;margin-bottom:14px"></div>`;
    box.appendChild(wrap);

    const dbox = wrap.querySelector("#days-"+w.n);
    if(w.days && w.days.length){
      w.days.forEach(d=>dbox.appendChild(dayEl(w,d)));
    } else {
      const tasks = DATA.weekDetail[String(w.n)] || [];
      const div = document.createElement("div");
      div.className = "card";
      div.innerHTML = `<h4>本周任务清单（每天一条）</h4>
        <ul class="tasks">${tasks.map(t=>"<li>"+t+"</li>").join("")}</ul>
        <p class="small muted" style="margin-top:10px">这一周没有逐日详解，按上面的清单做。做完在「我的进度」里手动打勾。</p>
        <button class="btn sm" style="margin-top:10px" onclick="toggleWeekDone(${w.n})">标记本周完成</button>`;
      dbox.appendChild(div);
    }
  });
}
function toggleWeek(n){
  S.openWeeks[n] = (S.openWeeks[n] === false);
  save();
  const el = document.getElementById("days-"+n);
  if(el) el.style.display = S.openWeeks[n]===false ? "none":"block";
}
function jumpWeek(n){
  const el = document.getElementById("week-"+n);
  if(el) el.scrollIntoView({behavior:"smooth",block:"start"});
}
function toggleWeekDone(n){
  const w = DATA.weeks.find(x=>x.n===n);
  const allDone = (w.days||[]).every(d=>S.done["w"+n+"d"+d.d]);
  (w.days||[]).forEach(d=>{ S.done["w"+n+"d"+d.d] = !allDone; });
  save(); renderCourse(); renderHome();
  toast(allDone?"已取消":"已标记完成");
}

function dayEl(w,d){
  const k = "w"+w.n+"d"+d.d;
  const done = !!S.done[k];
  const el = document.createElement("div");
  el.className = "day"+(done?" done":"");
  el.id = "day-"+w.n+"-"+d.d;
  el.innerHTML = `
    <div class="dh" onclick="toggleDay(${w.n},${d.d})">
      <span class="dn">D${d.d}</span>
      <span class="dt">${d.title}</span>
      <span class="dck">✓</span>
    </div>
    <div class="body">
      <div class="learn">${d.learn}</div>
      ${d.concepts&&d.concepts.length?`<div><h4>要懂的概念</h4><div class="concepts">${d.concepts.map(c=>`<div class="con"><b>${c[0]}</b>　${c[1]}</div>`).join("")}</div></div>`:""}
      ${d.tasks&&d.tasks.length?`<div><h4>动手做（照着敲，别复制）</h4><ul class="tasks">${d.tasks.map(t=>"<li>"+t+"</li>").join("")}</ul></div>`:""}
      ${d.code?`<div><h4>参考代码</h4><div class="codebox"><button class="cp" onclick="copyCode(this)">复制</button><pre>${esc(d.code)}</pre></div></div>`:""}
      ${d.check&&d.check.length?`<div><h4>做完检查（能打勾才算过）</h4><ul class="check">${d.check.map(c=>"<li>"+c+"</li>").join("")}</ul></div>`:""}
      <div style="display:flex;gap:10px;margin-top:16px;flex-wrap:wrap">
        <button class="btn ${done?"":"primary"}" onclick="markDay(${w.n},${d.d})">${done?"✓ 已完成（点击取消）":"标记为已完成"}</button>
        <button class="btn ghost sm" onclick="goNext(${w.n},${d.d})">下一天 →</button>
      </div>
    </div>`;
  return el;
}
function esc(s){ return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function copyCode(btn){
  const pre = btn.parentElement.querySelector("pre");
  navigator.clipboard.writeText(pre.textContent).then(()=>{ btn.textContent="已复制"; setTimeout(()=>btn.textContent="复制",1200); });
}
function toggleDay(w,d){
  const el = document.getElementById("day-"+w+"-"+d);
  if(el) el.classList.toggle("open");
}
function openDay(w,d){
  show("course");
  setTimeout(()=>{
    const el = document.getElementById("day-"+w+"-"+d);
    if(el){ el.classList.add("open"); el.scrollIntoView({behavior:"smooth",block:"center"}); }
  },80);
}
function markDay(w,d){
  const k = "w"+w+"d"+d;
  S.done[k] = !S.done[k];
  save(); renderCourse(); renderHome();
  toast(S.done[k]?"完成第 "+d+" 天":"已取消");
}
function goNext(w,d){
  const list = allDays();
  const i = list.findIndex(x=>x.week===w&&x.day===d);
  const nx = list[i+1];
  if(nx){ openDay(nx.week,nx.day); } else { toast("已经是最后一天"); }
}

/* ---------------- 知识库 ---------------- */
function renderConcepts(filter){
  const box = document.getElementById("conceptList");
  const kw = (filter||"").trim().toLowerCase();
  const list = DATA.concepts.filter(c=>!kw || c[0].toLowerCase().includes(kw) || c[1].toLowerCase().includes(kw));
  if(!list.length){ box.innerHTML = `<div class="empty">没找到。换个词试试。</div>`; return; }
  box.innerHTML = list.map(c=>`<div class="concept"><b>${c[0]}</b><p>${c[1]}</p></div>`).join("");
}

/* ---------------- 测验 ---------------- */
function renderQuiz(){
  const el = document.getElementById("quiz");
  const answered = Object.keys(S.quiz).filter(k=>S.quiz[k]).length;
  el.innerHTML = `<h2>概念测验 · <span class="small muted">${answered}/${DATA.quiz.length} 答对</span></h2>
    <p class="small muted" style="margin-bottom:14px">点一个选项，立刻知道对错和原因。答错的可以重答。</p>
    <div id="quizList"></div>`;
  const box = document.getElementById("quizList");
  DATA.quiz.forEach((q,i)=>{
    const div = document.createElement("div");
    div.className = "q";
    div.innerHTML = `<div class="qt">${i+1}. ${q.q}</div>
      <div class="opts"></div>
      <div class="why" id="why-${i}">${q.why}</div>`;
    const opts = div.querySelector(".opts");
    q.a.forEach((text,j)=>{
      const b = document.createElement("button");
      b.className = "opt";
      b.textContent = String.fromCharCode(65+j)+". "+text;
      b.onclick = ()=>{
        const right = j===q.ok;
        opts.querySelectorAll(".opt").forEach(x=>x.disabled=false);
        b.classList.add(right?"right":"wrong");
        if(!right){ opts.children[q.ok].classList.add("right"); }
        document.getElementById("why-"+i).classList.add("show");
        if(right){ S.quiz[i]=true; save(); }
        renderQuizStats();
      };
      opts.appendChild(b);
    });
    box.appendChild(div);
  });
}
function renderQuizStats(){
  const answered = Object.keys(S.quiz).filter(k=>S.quiz[k]).length;
  const h = document.querySelector("#quiz h2");
  if(h) h.innerHTML = `概念测验 · <span class="small muted">${answered}/${DATA.quiz.length} 答对</span>`;
}

/* ---------------- 速查卡 ---------------- */
const REF = __REF__;
const ERRORS = __ERRORS__;

function renderRef(){
  const el = document.getElementById("ref");
  el.innerHTML = `
    <h2>速查卡</h2>
    <div class="card">
      <h3>Python 最常用写法</h3>
      <table style="width:100%;border-collapse:collapse;font-size:13px;margin-top:10px">
        ${REF.map((r,i)=>`<tr>
          <td style="padding:7px 10px;border-bottom:1px solid #1a2230;color:${i?"var(--muted)":"var(--dim)"};width:38%">${r[0]}</td>
          <td style="padding:7px 10px;border-bottom:1px solid #1a2230;font-family:ui-monospace,monospace;font-size:12.5px;color:var(--cyan)">${esc(r[1])}</td>
        </tr>`).join("")}
      </table>
    </div>
    <div class="card">
      <h3>最常见的 10 个报错</h3>
      <table style="width:100%;border-collapse:collapse;font-size:13px;margin-top:10px">
        ${ERRORS.map(r=>`<tr>
          <td style="padding:8px 10px;border-bottom:1px solid #1a2230;font-family:ui-monospace,monospace;font-size:12px;color:var(--red);width:34%">${r[0]}</td>
          <td style="padding:8px 10px;border-bottom:1px solid #1a2230;color:var(--muted);width:22%">${r[1]}</td>
          <td style="padding:8px 10px;border-bottom:1px solid #1a2230;color:var(--dim);font-size:12.5px">${r[2]}</td>
        </tr>`).join("")}
      </table>
    </div>
    <div class="card">
      <h3>调试三步法</h3>
      <div class="grid g3" style="margin-top:10px">
        <div class="stat"><b style="font-size:15px;color:var(--cyan)">① 复现</b><span>让它每次都错。不能复现的 bug 修不了。</span></div>
        <div class="stat"><b style="font-size:15px;color:var(--cyan)">② 缩小</b><span>注释掉一半代码，看还错不错。</span></div>
        <div class="stat"><b style="font-size:15px;color:var(--cyan)">③ 验证</b><span>写个测试，证明修好了。</span></div>
      </div>
    </div>
    <div class="card">
      <h3>问 AI 的正确姿势</h3>
      <div class="grid g2" style="margin-top:10px">
        <div class="stat"><b style="font-size:14px;color:var(--green)">✅ 可以问</b><span>这个报错是什么意思？该检查哪几行？<br/>lambda 在这里干什么？用大白话解释。<br/>帮我 review 这段，指出 3 个可能出错的地方。</span></div>
        <div class="stat"><b style="font-size:14px;color:var(--red)">❌ 不要问</b><span>帮我写一个完整的 XXX。<br/>这段我看不懂，你重写一遍。<br/>直接给我能跑的版本。</span></div>
      </div>
      <p class="small muted" style="margin-top:12px">判断标准：问完之后，你能不能用大白话讲给一个不懂的人听？能 → 有效学习；不能 → 你只是在搬运。</p>
    </div>`;
}

/* ---------------- 进度 ---------------- */
function renderProgress(){
  const el = document.getElementById("progress");
  const p = pct();
  el.innerHTML = `
    <h2>我的进度</h2>
    <div class="grid g4" style="margin-bottom:16px">
      <div class="stat"><b>${p}%</b><span>完成度</span><div class="sub">${doneCount()}/${totalDays()} 天</div></div>
      <div class="stat"><b>${daysSince()}</b><span>坚持天数</span><div class="sub">从 ${S.started}</div></div>
      <div class="stat"><b>${Object.keys(S.quiz).filter(k=>S.quiz[k]).length}</b><span>测验答对</span><div class="sub">共 ${DATA.quiz.length} 题</div></div>
      <div class="stat"><b>${DATA.weeks.filter(w=>weekProgress(w)===100).length}</b><span>完成的周</span><div class="sub">共 12 周</div></div>
    </div>
    <div class="card">
      <h3>逐周进度</h3>
      <div style="margin-top:12px">
        ${DATA.weeks.map(w=>`
          <div style="margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px">
              <span>W${w.n} ${w.title}</span><span class="mono" style="color:var(--amber)">${weekProgress(w)}%</span>
            </div>
            <div class="bar ${weekProgress(w)===100?'g':''}"><i style="width:${weekProgress(w)}%"></i></div>
          </div>`).join("")}
      </div>
    </div>
    <div class="card">
      <h3>每天 3 行日志（自己写在笔记里）</h3>
      <div class="codebox"><button class="cp" onclick="copyCode(this)">复制</button><pre>日期：
今天写了什么：
卡住的点：
想通的一句话：</pre></div>
      <p class="small muted" style="margin-top:10px">写在 ~/fde-code/notes/ 里。12 周后，这 80 多条日志就是你「学习能力」的证据。</p>
    </div>`;
}

/* ---------------- 导入导出 ---------------- */
document.getElementById("export").onclick = ()=>{
  const blob = new Blob([JSON.stringify(S,null,2)],{type:"application/json"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "fde-progress-"+todayStr()+".json";
  a.click(); URL.revokeObjectURL(a.href);
  toast("已导出");
};
document.getElementById("import").onclick = ()=>{
  const inp = document.createElement("input"); inp.type="file"; inp.accept=".json";
  inp.onchange = ()=>{
    const f = inp.files[0]; if(!f) return;
    const r = new FileReader();
    r.onload = ()=>{ try{ S = JSON.parse(r.result); save(); renderAll(); toast("已导入"); }catch(e){ toast("解析失败"); } };
    r.readAsText(f);
  };
  inp.click();
};
document.getElementById("reset").onclick = ()=>{
  if(confirm("清空所有进度？不可撤销。")){
    S = { done:{}, quiz:{}, openWeeks:{}, started: todayStr() };
    save(); renderAll(); toast("已重置");
  }
};

/* ---------------- 导航 ---------------- */
function show(name){
  const b = document.querySelector('.tab[data-t="'+name+'"]');
  if(!b) return;
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("on",x===b));
  document.querySelectorAll("section").forEach(s=>s.classList.toggle("on",s.id===name));
  if(name==="home") renderHome();
  if(name==="course") renderCourse();
  if(name==="progress") renderProgress();
  if(name==="quiz") renderQuiz();
  if(name==="ref") renderRef();
  window.scrollTo({top:0,behavior:"smooth"});
}
document.getElementById("nav").addEventListener("click",e=>{
  const b = e.target.closest(".tab"); if(!b) return;
  show(b.dataset.t);
});
document.getElementById("search").addEventListener("input",e=>renderConcepts(e.target.value));

/* ---------------- 初始化 ---------------- */
function renderAll(){
  renderHome(); renderCourse(); renderConcepts(""); renderQuiz(); renderRef(); renderProgress();
}
renderAll();
</script>
</body>
</html>
"""

REF_DATA = [
    ("想干什么", "怎么写"),
    ("打印", 'print("内容")'),
    ("变量", 'name = "值"'),
    ("字符串拼数字", '"a" + str(123)'),
    ("转数字", 'int("123")'),
    ("判断", "if x > 10: / elif / else:"),
    ("循环列表", "for x in items:"),
    ("循环次数", "for i in range(5):"),
    ("列表", "items = [1, 2, 3]"),
    ("加元素", "items.append(4)"),
    ("长度", "len(items)"),
    ("字典", 'd = {"k": 1}'),
    ("安全取值", 'd.get("k", 默认值)'),
    ("排序", "sorted(items)"),
    ("按字段排序", 'sorted(items, key=lambda x: x["stars"])'),
    ("定义函数", "def f(a, b):"),
    ("返回", "return 结果"),
    ("读文件", 'with open(p, "r", encoding="utf-8") as f:'),
    ("读所有行", "f.readlines()"),
    ("写文件", 'with open(p, "w", encoding="utf-8") as f:'),
    ("去空白", "s.strip()"),
    ("切分", "s.split()"),
    ("替换", 's.replace("旧", "新")'),
    ("包含", '"词" in s'),
    ("转 JSON", "json.loads(text) / json.load(f)"),
    ("转 JSON 字符串", "json.dumps(obj, ensure_ascii=False)"),
    ("跑测试", "python3 -m unittest -v"),
    ("看报错", "先看最后一行 + File/line"),
]

ERROR_DATA = [
    ("SyntaxError", "语法错", "括号、引号、冒号是否成对"),
    ("IndentationError", "缩进错", "混用空格和 Tab"),
    ("NameError", "变量没定义", "拼写？定义在下面？"),
    ("TypeError", "类型不对", "字符串加数字？忘了 str/int"),
    ("KeyError", "字典没这个键", "用 .get() 代替 []"),
    ("IndexError", "列表越界", "列表空？索引从 0 开始"),
    ("FileNotFoundError", "找不到文件", "路径对不对？ls 看看"),
    ("ValueError", "值不对", 'int("abc") 会报这个'),
    ("AttributeError", "对象没这属性", "None.xxx 最常见"),
    ("ModuleNotFoundError", "模块没装", "pip install 模块名"),
]

def js_json(obj):
    t = json.dumps(obj, ensure_ascii=False)
    return t.replace("</", "<\\/")

html = HTML.replace("__PAYLOAD__", payload)
html = html.replace("__REF__", js_json(REF_DATA))
html = html.replace("__ERRORS__", js_json(ERROR_DATA))
OUT.write_text(html, encoding="utf-8")
print("已生成：", OUT)
print("大小：", round(len(html) / 1024, 1), "KB")
print("天数：", sum(len(w["days"]) for w in WEEKS))
print("概念：", len(CONCEPTS), "测验：", len(QUIZ))
